#include <windows.h>
#include <commdlg.h>
#include <string.h>
#include <io.h>
#include <memory.h>


#define ASCII_STX      0x02
#define ASCII_ETX      0x03

#define ASCII_A8		0xA8
#define ASCII_8A		0x8A


BOOL NEAR WriteTTYBlock( HWND, LPSTR, int ) ;
BOOL NEAR WriteCommBlock( HWND , LPSTR, DWORD);

void Chk_CmdString(HWND hWnd);
int Get_CmdString(LPSTR lpBlock, int nLength );

